# Fossilizer - A Taphonomy Game
### April/23

### author: Marcelo Pastana Duarte

### This game app was developed for use in portrait mode on iPhone



